package careIo.com.careIo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CareIoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CareIoApplication.class, args);
	}

}
